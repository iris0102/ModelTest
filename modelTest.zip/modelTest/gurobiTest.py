# -*- coding: cp936 -*-
import copy

from gurobipy import *
from Initial_Topo import *


#====================Initial Variables ===================
def find_MF_node_Set (CNT_Tk,List_Tk,MF_switch_fun):
    MF_node_FlowSet ={}
    for i in range (CNT_Tk):
        MF_node_FlowSet[i]=[]
        target_fun = List_Tk[i][4]

        for j in range(N):
            switch_MF = MF_switch_fun[j]
            if len(target_fun)<= len(switch_MF):
                sum_target_fun =0
                for n in range(len(target_fun)):
                    if target_fun[n] in switch_MF:
                        sum_target_fun =sum_target_fun +1
                if sum_target_fun == len(target_fun):
                    MF_node_FlowSet[i].append(j)  
    return MF_node_FlowSet


def find_FlowSet_MF_factorReal (CNT_Tk,List_Tk,MF_factor): 
    FlowSet_MF_factorReal = {}
    for i in range (CNT_Tk):
        FlowSet_MF_factorReal[i]=[]
        target_fun = List_Tk[i][4]
        FlowSet_MF_factor =1
        for j in range (len(target_fun)):
            if target_fun[j]=='A':
                FlowSet_MF_factor = FlowSet_MF_factor * MF_factor[0]
            elif target_fun[j]=='B':
                FlowSet_MF_factor = FlowSet_MF_factor * MF_factor[1]
            elif target_fun[j]=='C':
                FlowSet_MF_factor = FlowSet_MF_factor * MF_factor[2]
            elif target_fun[j]=='D':
                FlowSet_MF_factor = FlowSet_MF_factor * MF_factor[3]
        FlowSet_MF_factorReal[i]=FlowSet_MF_factor
    return FlowSet_MF_factorReal


def GurobiSolver_initial (CNT_Tk, List_Tk,MF_switch_fun,MF_factor):

    MF_node_FlowSet = find_MF_node_Set (CNT_Tk,List_Tk,MF_switch_fun)

    FlowSet_MF_factorReal = find_FlowSet_MF_factorReal (CNT_Tk,List_Tk,MF_factor)
    
    return MF_node_FlowSet,FlowSet_MF_factorReal


#==================== output routingPath ===================

def Transform_PathIntoLinks (list_path_j, pathIndex): 
    j=pathIndex 
    list_path_candidate_i =[]
    cnt =0
    while cnt < len(list_path_j)-1:
        In =list_path_j[cnt]
        rn=list_path_j[cnt+1]
        tuple =In, rn
        list_path_candidate_i.append(tuple)
        cnt=cnt+1
    return list_path_candidate_i


def find_routingPath_EachTimeslot_noCandidatePath (CNT_Tk,dVar_z_k_uv,):
    RoutingPath ={}
    for k in range(CNT_Tk):
        instead_path={}
        RoutingPath [k]=[]
        for (u, v) in dvalid_links:
            if dVar_z_k_uv[k,u,v].getAttr('x')>0.1:
                instead_path[(u,v)] =[]
                instead_path[(u,v)]=int(dVar_z_k_uv[k,u,v].getAttr('x'))  
        RoutingPath[k]=instead_path

    RoutingPath_order ={}
    for i in range(CNT_Tk):
        RoutingPath_order[i]=[]
        RoutingPath_order[i]=sorted(RoutingPath[i].items(), key=lambda d: d[1])

    FinalRoutingPath = {}
    for i in range (CNT_Tk):
        FinalRoutingPath[i]=[]
        finalPath =[]
        for j in range(len(RoutingPath_order[i])):
            finalPath.append(RoutingPath_order[i][j][0][0])
        finalPath.append((RoutingPath_order[i][j][0][1]))
        FinalRoutingPath[i] =finalPath
    return RoutingPath,RoutingPath_order,FinalRoutingPath


#==================== start Gurobi ===================
def main_noCandidatePath_SolverAndMetris (CNT_Tk, List_Tk,MF_switch_fun,MF_factor):
    MF_node_FlowSet,FlowSet_MF_factorReal  =GurobiSolver_initial (CNT_Tk, List_Tk,MF_switch_fun,MF_factor) 

    #GurobiSolver
    #========================(1) create model =============================
    model =Model('minLoadBalance')
    model.setParam ('outputFlag', True)
    #==========================(2) add Variables ===========================
    #1--dVar_y_k_uv  
    dVar_y_k_uv ={}
    for k in range(CNT_Tk):
        for u,v in dvalid_links:
            dVar_y_k_uv[k,u,v] = model.addVar(vtype=GRB.BINARY, lb=0, ub=1, name='dVar_y_k_uv[ %s %s %s]'%(k,u,v) )
    model.update()


    #2--dVar_x_k_u
    dVar_x_k_u ={}
    for k in range(CNT_Tk):
        for u in MF_node_FlowSet[k]:
            dVar_x_k_u[k,u] = model.addVar (vtype=GRB.BINARY, lb=0,ub=1,name='dVar_x_k_u[ %s %s]'%(k,u))
    model.update()


    #3--dVar_z_k_uv 
    dVar_z_k_uv ={}
    for k in range(CNT_Tk):
        for u,v in dvalid_links:
            dVar_z_k_uv[k,u,v] = model.addVar(vtype=GRB.INTEGER, lb=0, name='dVar_z_k_uv[ %s %s %s]'%(k,u,v) )
    model.update()



    #4--dVar_mu_uv---LB factor
    dVar_mu_uv={}
    for u,v in dvalid_links:
        dVar_mu_uv[u,v] =model.addVar( vtype=GRB.CONTINUOUS, lb=0.0, ub=1.0, name='dVar_mu_uv[%s %s]'%(u,v))
    model.update() 


    ## =========================== (3) Add constraints===========================

    #----------A.  flow conservation-----------#
    for k in range(CNT_Tk):
        sf =List_Tk[k][0]
        sumA0 =0
        sumB0 =0
        for u, v in dvalid_links:
            if u == sf:
                sumA0 = sumA0 + dVar_y_k_uv[k,u,v]
            elif v ==sf:
                sumB0 = sumB0 + dVar_y_k_uv[k,u,v]

        model.addConstr(sumA0 - sumB0 ==1) 
    model.update()    


    for k in range(CNT_Tk):
        tf =List_Tk[k][1]
        sumA1 =0
        sumB1 =0
        for u, v in dvalid_links:
            if v == tf:
                sumA1 = sumA1 + dVar_y_k_uv[k,u,v]
            elif u ==tf:
                sumB1 = sumB1 + dVar_y_k_uv[k,u,v]

        model.addConstr(sumA1 - sumB1 ==1) 
    model.update()      


    for k in range(CNT_Tk):
        sf =List_Tk[k][0]
        tf =List_Tk[k][1]
        for v in range(N):
            if v!= sf and v != tf:
                sumA2 =0
                sumB2 =0
                for u in range(N):
                    if (u, v) in dvalid_links:
                        sumA2 = sumA2 + dVar_y_k_uv[k,u,v]
                for w in range(N):
                    if (v, w) in dvalid_links:
                        sumB2 = sumB2 + dVar_y_k_uv[k,v,w]
                model.addConstr(sumA2 - sumB2 ==0) 
    model.update() 

    #----------B.  loop constriant-----------#
    for k in range(CNT_Tk):
        for u,v in dvalid_links:
            model.addConstr( dVar_z_k_uv[k,u,v] <= dVar_y_k_uv[k,u,v]*(N-1) ) 
    model.update()  


    for k in range(CNT_Tk):
        tf =List_Tk[k][1]
        for v in range(N):
            if v != tf:
                sumA3 =0
                sumB3 =0
                sumC3 =0          
                for w in range(N):            
                    if (v,w) in dvalid_links:
                            sumA3 = sumA3 + dVar_z_k_uv[k,v,w]
                for u in range(N):  
                    if (u,v) in dvalid_links:
                            sumB3 = sumB3 + dVar_z_k_uv[k,u,v]
                for w in range(N):  
                    if (v,w) in dvalid_links:
                            sumC3 = sumC3 + dVar_y_k_uv[k,v,w]                       
                model.addConstr(sumA3 - sumB3 ==sumC3) 
    model.update()                         

    #----------C.1  MF constriant-----------# 
    for k in range(CNT_Tk):
        tf =List_Tk[k][1]
        for u in MF_node_FlowSet[k]:
            #print "u =", u
            sumA4 =0
            for v in range(N):
                if (u,v) in dvalid_links:
                    sumA4 = sumA4 + dVar_y_k_uv[k,u,v]
                    if (v,tf) in dvalid_links:
                        sumA4 = sumA4 + dVar_y_k_uv[k,v,tf]
            model.addConstr( dVar_x_k_u[k,u] <= sumA4 ) 
    model.update() 

    for k in range(CNT_Tk):
        sf =List_Tk[k][0]
        sumA5 =0
        sumB5 =0 
        for u in range(N):
            if u in MF_node_FlowSet[k]:
                sumA5 = sumA5 + dVar_x_k_u[k,u]
        for v in range(N):
            if (sf,v) in dvalid_links:
                sumB5 = sumB5 + dVar_y_k_uv[k,sf,v]       
        model.addConstr( sumA5 >= sumB5 ) 
    model.update()

    #----------C.2   MF constriant_capacity-----------#

    for u in range(N):
        if MF_node[u] == 1:
            sumMF_in_node =0
            for k in range(CNT_Tk):
                if u in MF_node_FlowSet[k]:
                    sumMF_in_node = sumMF_in_node + dVar_x_k_u[k,u]* List_Tk[k][2]
            model.addConstr(sumMF_in_node <= MF_uv[u])                
    model.update()   

    #--------- D.  TCAM constriant-----------#
    for u in range(N):
        sumRule_in_node =0
        for k in range(CNT_Tk):
            for v in range (N):
                if (u,v) in dvalid_links: 
                    sumRule_in_node = sumRule_in_node+ dVar_y_k_uv[k,u,v] * List_Tk[k][5]
        model.addConstr(sumRule_in_node <= T_u[u])   
    model.update() 

    #----------E  bandwidth constriant-----------#
    sumLink ={}
    df_k_uv={}
    for u, v in dvalid_links:
        sumLink[(u,v)] =0
        for k in range(CNT_Tk):
            df_k_uv[(k,u,v)] = List_Tk[k][2]
            if u in MF_node_FlowSet[k]:
                df_k_uv[(k,u,v)] =  List_Tk[k][2] * (1+dVar_x_k_u [k,u] *FlowSet_MF_factorReal[k])
            sumLink[(u,v)] =sumLink[(u,v)] + dVar_y_k_uv[k,u,v] * df_k_uv[(k,u,v)]


        if B_uv[u][v]!=0:
            model.addConstr( sumLink[(u,v)] <=  dVar_mu_uv[u,v]* float(B_uv[u][v])  )
    model.update()  


    # =========================== (4) set objectives ===========================
    sumLink_new ={}
    df_k_uv={}
    for u, v in dvalid_links:
        sumLink_new[(u,v)] =0
        for k in range(CNT_Tk):
            df_k_uv[(k,u,v)] = List_Tk[k][2]
            if u in MF_node_FlowSet[k]:
                df_k_uv[(k,u,v)] =  List_Tk[k][2] * (1+dVar_x_k_u [k,u] *FlowSet_MF_factorReal[k])
            sumLink_new[(u,v)] =sumLink_new[(u,v)] + dVar_y_k_uv[k,u,v] * df_k_uv[(k,u,v)]

        if B_uv[u][v]!=0:
            load_instead = sumLink[(u,v)] / float(B_uv[u][v]) 
            model.setObjective(load_instead ,GRB.MINIMIZE)


    # =========================== (5) Compute optimal solution ===========================
    model.optimize()

    # ======================== 6 Print solution ===========================
    if model.status == GRB.status.OPTIMAL:
        print "hello optimal"
    else:
        print '\n---------------------------------------------- Hello, Failed to solve this model !!\n',
        model.computeIIS()
        model.write("model_rec.ilp")
        print '\n------- Did not Optimized. ----------\n'

    if model.status == GRB.status.OPTIMAL:

        print '\n-------------1--dVar_y_k_uv-------------------\n'    

        for k in range(CNT_Tk):
            for u, v in dvalid_links:
                if  dVar_y_k_uv[k,u,v].getAttr("x") >=0.000001:
                    print 'dVar_y_k_uv[%d %d %d]--%d'%(k,u,v, dVar_y_k_uv[k,u,v].getAttr('x'))


        print '\n-------------2--dVar_x_k_u-------------------\n'    

        for k in range(CNT_Tk):
                for u in MF_node_FlowSet[k]:
                    if  dVar_x_k_u[k,u].getAttr("x") >=0.000001:
                         print 'dVar_x_k_u[ %d %d]--%d'%(k,u,dVar_x_k_u[k,u].getAttr('x'))

        print '\n-------------3--dVar_z_k_uv-------------------\n'    

        for k in range(CNT_Tk):
            for u, v in dvalid_links:
                if  dVar_z_k_uv[k,u,v].getAttr("x") >=0.000001:
                    print 'dVar_z_k_uv[%d %d %d]--%d'%(k,u,v, dVar_z_k_uv[k,u,v].getAttr('x'))                        


        print '\n-------------4--dVar_mu_uv--------------------\n'    

        for u,v in dvalid_links:
            if dVar_mu_uv[u,v].getAttr("x") >=0.00001:
                 print 'dVar_mu_uv[%d %d]--%d'%(u,v,dVar_mu_uv[u,v].getAttr('x'))


        print '\n------------- 3_OPT_val --------------------'
        print 'dVar_mu_uv[u,v] ==',model.ObjVal



    RoutingPath,RoutingPath_order,FinalRoutingPath =find_routingPath_EachTimeslot_noCandidatePath (CNT_Tk,dVar_z_k_uv)
    print "RoutingPath =",RoutingPath
    print "\nRoutingPath_order=",RoutingPath_order
    print "FinalRoutingPath=",FinalRoutingPath

    #==================== Inspect routing path ===================

    def Inspect_FinalRoutingPath (CNT_Tk,List_Tk,FinalRoutingPath):
        ErrorFlowIndex =[]
        flagFinalRoutingPath =0
        for i in range(CNT_Tk):
            if List_Tk[i][0] != FinalRoutingPath[i][0] or List_Tk[i][1] != FinalRoutingPath[i][-1]:
                flagFinalRoutingPath =1
                print "\n====== Error: FinalRouringPath ==== !"
                print "flowIndex =",i
                ErrorFlowIndex.append(i)
            if i not in ErrorFlowIndex:
                # transform links; if links not in dvalid_links, delte
                list_path_i = FinalRoutingPath[i]
                list_path_candidate_i = Transform_PathIntoLinks (list_path_i, pathIndex =0 )  #
                for m in range(len(list_path_candidate_i)):
                    In =list_path_candidate_i[m][0]
                    Rn =list_path_candidate_i[m][1]
                    if (In, Rn) not in dvalid_links:
                        print "\n====== Error: FinalRouringPath-not in dvalid_links ==== !"
                        print "flowIndex =",(In, Rn)
                        ErrorFlowIndex.append(i)
                        break
          
        if flagFinalRoutingPath ==0:
            print "\n======= Pass: FinalRoutingPath ====== !\n"
        return ErrorFlowIndex

    ErrorFlowIndex = Inspect_FinalRoutingPath(CNT_Tk,List_Tk,FinalRoutingPath)

    def update_delteErrorFlowIndex (ErrorFlowIndex, CNT_Tk, List_Tk,FinalRoutingPath ):

        if len(ErrorFlowIndex) !=0:
            CNT_Tk_update =copy.deepcopy(CNT_Tk) 
            List_Tk_update =copy.deepcopy(List_Tk)
            FinalRoutingPath_update =copy.deepcopy(FinalRoutingPath)
            j=len(ErrorFlowIndex)-1
            for i in range(len(ErrorFlowIndex)):
                CNT_Tk_update =CNT_Tk_update -1
                List_Tk_update.pop(ErrorFlowIndex[j])
                FinalRoutingPath_update.pop(ErrorFlowIndex[i])
                j=j-1
            print " CNT_Tk and List_Tk are updated!"    
        else:
            CNT_Tk_update= CNT_Tk
            List_Tk_update =List_Tk
            FinalRoutingPath_update =FinalRoutingPath
            print "len(ErrorFlowIndex) =0, No necessary to update CNT_Tk and List_Tk !"
        return CNT_Tk_update,List_Tk_update,FinalRoutingPath_update

    CNT_Tk_update,List_Tk_update,FinalRoutingPath_update = update_delteErrorFlowIndex (ErrorFlowIndex, CNT_Tk, List_Tk ,FinalRoutingPath)
    CNT_Tk =CNT_Tk_update
    List_Tk =List_Tk_update
    FinalRoutingPath = FinalRoutingPath_update
    
    return ErrorFlowIndex,FinalRoutingPath


if __name__ == "__main__":
    pass
