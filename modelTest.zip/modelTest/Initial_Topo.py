# -*- coding: utf-8 -*-

import random
import numpy as np 
import networkx as nx
from itertools import combinations


G_Italy=nx.Graph()
G_Italy.add_nodes_from([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20])
G_Italy.add_edges_from([
                       (0,1),(0,2),(0,4),(0,6),(0,7),(0,8),
                       (1,0),(1,2),(1,5),
                       (2,1),(2,3),
                       (3,2),(3,4),
                       (4,0),(4,3),(4,9),(4,10),(4,11),
                       (5,1),(5,6),
                       (6,0),(6,5),(6,7),
                       (7,0),(7,6),(7,8),
                       (8,0),(8,7),(8,9),(8,12),
                       (9,4),(9,8),(9,11),
                       (10,4),(10,11),(10,13),
                       (11,4),(11,9), (11,10),(11,13), (11,14),
                       (12,8),(12,14),
                       (13,10),(13,11),(13,14),(13,17),(13,18),
                       (14,11),(14,12),(14,13),(14,15),(14,16),
                       (15,14),(15,16), (15,18),(15,19),
                       (16,14),(16,15),(16,20),
                       (17,13),(17,18),
                       (18,13),(18,15),(18,17),(18,19),
                       (19,15),(19,18),(19,20),
                       (20,16),(20,19)    
                      ])

#===================1.1  Given the topology of controller, 1 root controller + 4 local controllers

N_controller = 1
C_UV = [1,1,1,1]
C_E_UV = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

Cpa_Controller_UB=2000
Cpa_Controller_LB=1500

C_uv=[0 for i in range(N_controller)]
for i in range(N_controller):
    if C_UV[i]>0:
        C_uv[i]=random.randint(Cpa_Controller_LB, Cpa_Controller_UB)



N=21 #number of switches
M_E_UV = [
[0, 1,1,0,1,0, 1,1,1,0,0, 0,0,0,0,0, 0,0,0,0,0],
    
[1, 0,1,0,0,1, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0],
[1, 1,0,1,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0],
[0, 0,1,0,1,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0],
[1, 0,0,1,0,0, 0,0,0,1,1, 1,0,0,0,0, 0,0,0,0,0],
[0, 1,0,0,0,0, 1,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0],
    
[1, 0,0,0,0,1, 0,1,0,0,0, 0,0,0,0,0, 0,0,0,0,0],
[1, 0,0,0,0,0, 1,0,1,0,0, 0,0,0,0,0, 0,0,0,0,0],
[1, 0,0,0,0,0, 0,1,0,1,0, 0,1,0,0,0, 0,0,0,0,0],
[0, 0,0,0,1,0, 0,0,1,0,0, 1,0,0,0,0, 0,0,0,0,0],
[0, 0,0,0,1,0, 0,0,0,0,0, 1,0,1,0,0, 0,0,0,0,0],
    
[0, 0,0,0,1,0, 0,0,0,1,1, 0,0,1,1,0, 0,0,0,0,0],
[0, 0,0,0,0,0, 0,0,1,0,0, 0,0,0,1,0, 0,0,0,0,0],
[0, 0,0,0,0,0, 0,0,0,0,1, 1,0,0,1,0, 0,1,1,0,0],
[0, 0,0,0,0,0, 0,0,0,0,0, 1,1,1,0,1, 1,0,0,0,0],
[0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 1,0,1,1,0],
    
[0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,1, 0,0,0,0,1],
[0, 0,0,0,0,0, 0,0,0,0,0, 0,0,1,0,0, 0,0,1,0,0],
[0, 0,0,0,0,0, 0,0,0,0,0, 0,0,1,0,1, 0,1,0,1,0],
[0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,1, 0,0,1,0,1],
[0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 1,0,0,1,0]
]


#=== 1.2 given constant matrix of B_uv, the bandwidth of each link, x Mb/s

Cpa_Link_UB=200
Cpa_Link_LB=150

B_uv=[[0 for i in range(N)] for j in range(N)]
for i in range(N):
    for j in range(N):
        if M_E_UV[i][j]>0:
            B_uv[i][j]=random.randint(Cpa_Link_LB, Cpa_Link_UB)
            
            
            
dvalid_links={}
for i in range (N):
    for j in range (N):
        if M_E_UV[i][j]>0:
            dvalid_links [i,j] =M_E_UV[i][j]

dB_uv={}
for i,j in dvalid_links:
    dB_uv[i,j]=B_uv[i][j]

# ====== 1.3 TCAM===========
Cpa_TCAM_UB=200
Cpa_TCAM_LB=150
T_u=[0 for i in range(N)]
for i in range(N):
        T_u[i]=random.randint(Cpa_TCAM_LB, Cpa_TCAM_UB)


# ====== 1.4 MF ===========

MF_N = 4
MF_fuc =['A','B','C','D']
MF_factor = [0.6,1.5,0.8,2]
MF_E_uv =[[1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0], 
          [1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0], 
          [1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0], 
          [1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0]
         ]

MF_node =[0 for i in range(N)] 
for i in range(N):
    for j in range(MF_N ):
        if MF_E_uv[j][i] != 0:
            MF_node[i] =1


Cpa_MF_UB=200
Cpa_MF_LB=150
MF_uv=[0 for i in range(N)]
for j in range(N):
    for i in range(MF_N):
        if MF_E_uv[i][j]>0:
            MF_uv[j]=random.randint(Cpa_MF_LB, Cpa_MF_UB)


MF_fuc_series =[]
MF_factor_series =[]
for i in range(1,MF_N+1):
    aa = list(combinations(MF_fuc, i))
    bb = list(combinations(MF_factor, i))
    for j in range (len(aa)):
        MF_fuc_series.append(aa[j])
        MF_factor_series.append(bb[j])


MF_switch_fun ={}
for i in range (N):
    MF_switch_fun[i] =[]
    MF_function_type =[]
    for j in range(MF_N):
        if MF_E_uv[j][i] ==1:
            MF_function_type.append(MF_fuc[j])
            
    MF_switch_fun[i] =MF_function_type



if __name__ == "__main__":
    pass
