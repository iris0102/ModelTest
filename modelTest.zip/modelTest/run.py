# -*- coding: cp936 -*-

from Initial_Topo import *
from gurobiTest import *


TimeSlot= 3
CNT_Tk_value= {0: 7, 1: 6, 2: 8}
List_Tk_value= {0: [[13, 17, 38, 109, ['A', 'B', 'C', 'D'], 14, 2], [3, 12, 28, 99, ['A', 'B', 'D'], 11, 1], [1, 5, 31, 94, ['C'], 11, 3], [4, 11, 13, 26, ['A', 'C', 'D'], 16, 2], [5, 17, 37, 70, ['C'], 20, 4], [3, 17, 19, 18, ['A', 'B', 'C', 'D'], 20, 1], [7, 17, 19, 106, ['A', 'B', 'D'], 14, 3]], 1: [[9, 6, 15, 46, ['C', 'D'], 16, 2], [11, 9, 14, 8, ['A', 'B', 'C'], 18, 1], [16, 6, 14, 35, ['A', 'D'], 16, 2], [16, 2, 24, 19, ['A', 'C', 'D'], 13, 3], [12, 4, 11, 63, ['D'], 12, 4], [1, 7, 13, 13, ['A'], 19, 2]], 2: [[2, 3, 40, 6, ['B', 'D'], 19, 3], [17, 7, 10, 15, ['A', 'B', 'C', 'D'], 17, 1], [17, 18, 35, 20, ['B', 'C', 'D'], 12, 2], [19, 15, 27, 8, ['A'], 14, 3], [13, 14, 13, 9, ['B', 'C', 'D'], 15, 4], [3, 14, 26, 26, ['C'], 11, 3], [3, 19, 11, 37, ['C', 'D'], 15, 3], [8, 1, 12, 9, ['A', 'C', 'D'], 15, 2]]}


ErrorFlowIndex_new ={}  
FinalRoutingPath_new ={}

for i in range (TimeSlot):
    ErrorFlowIndex_new [i] =[] 
    FinalRoutingPath_new[i] =[]

    
    CNT_Tk =CNT_Tk_value[i]
    List_Tk =List_Tk_value[i]

    ErrorFlowIndex,FinalRoutingPath=main_noCandidatePath_SolverAndMetris (CNT_Tk, List_Tk, MF_switch_fun,MF_factor)
    
    ErrorFlowIndex_new[i] =ErrorFlowIndex 
    FinalRoutingPath_new[i] = FinalRoutingPath

print "ErrorFlowIndex_Timeslot =",ErrorFlowIndex_new    
print "FinalRoutingPath_Timeslot=",FinalRoutingPath_new